# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-10

### Added

- Initial Python implementation of the SCOPE model
- Radiative transfer models: Fluspect, BSM, RTMo, RTMf, RTMt, RTMz
- Energy balance module with Farquhar photosynthesis and Ball-Berry conductance
- Supporting utilities: leaf angle distributions, physics functions, numerical integration
- I/O module for configuration loading, time series, atmospheric data, and output writing
- Typed dataclass structures for all model inputs and outputs
- CLI entry point (`scope` command)
- Verification tools for comparing Python and MATLAB implementations
